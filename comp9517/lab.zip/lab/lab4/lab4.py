from sklearn import metrics
from sklearn.datasets import load_digits
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier
from sklearn.linear_model import SGDClassifier
from sklearn.tree import DecisionTreeClassifier
import numpy as np
import matplotlib.pyplot as plt
from sklearn.metrics import recall_score

from sklearn.metrics import confusion_matrix
import math

digits = load_digits()
##plt.gray() 
##plt.matshow(digits.images[0])
##plt.show() 
#plt.imshow(np.reshape(digits.data[0], (8, 8)), cmap='gray')
#plt.title('Label: %i\n' % digits.target[0], fontsize=25)

X = digits.data
Y = digits.target
X_train, X_test, Y_train, Y_test = train_test_split(X, Y, test_size=0.25, random_state=42)

#KNeighborsClassifier
knn = KNeighborsClassifier(n_neighbors=5)
knn.fit(X_train,Y_train)
knn_pre_values = knn.predict(X_test)
con_mat = confusion_matrix(Y_test, knn_pre_values)
KNN_Accuracy = knn.score(X_test, Y_test)
KNN_Recall = recall_score(Y_test, knn_pre_values, average='macro')

#SGDClassifier
clf = SGDClassifier()
clf.fit(X_train,Y_train)
clf_pre_values = clf.predict(X_test)
SGT_Accuracy = clf.score(X_test, Y_test)
SGT_Recall = recall_score(Y_test, clf_pre_values, average='macro')

#DecisionTreeClassifier
dt = DecisionTreeClassifier(random_state=0)
dt.fit(X_train,Y_train)
dt_pre_values = dt.predict(X_test)
DT_Accuracy = dt.score(X_test, Y_test)
DT_Recall = recall_score(Y_test, dt_pre_values, average='macro')

KNN_Accuracy = str(round(KNN_Accuracy, 3))
KNN_Recall = str(round(KNN_Recall, 3))
SGT_Accuracy = str(round(SGT_Accuracy, 3))
SGT_Recall = str(round(SGT_Recall, 3))
DT_Accuracy = str(round(DT_Accuracy, 3))
DT_Recall = str(round(DT_Recall, 3))
print('''COMP9517 Week5 Lab - z5177242
Test size = 0.25
KNN Accuracy: {KA}    Recall:{KR}
SGT_Accuracy: {SA}    Recall:{SR}
DT_Accuracy:  {DA}    Recall:{DR}

KNN Confusion Matrix:
{CM}
'''.format(KA = KNN_Accuracy,KR = KNN_Recall,SA = SGT_Accuracy, SR = SGT_Recall,
           DA = DT_Accuracy, DR = DT_Recall, CM = con_mat))






