# Template for lab02 task 3

import cv2 
import math
import numpy as np
import sys

class SiftDetector():
    def __init__(self, norm="L2", params=None):
        self.detector=self.get_detector(params)
        self.norm=norm

    def get_detector(self, params):
        if params is None:
            params={}
            params["n_features"]=49
            params["n_octave_layers"]=3
            params["contrast_threshold"]=0.04
            params["edge_threshold"]=10
            params["sigma"]=1.6

        detector = cv2.xfeatures2d.SIFT_create(
                nfeatures=params["n_features"],
                nOctaveLayers=params["n_octave_layers"],
                contrastThreshold=params["contrast_threshold"],
                edgeThreshold=params["edge_threshold"],
                sigma=params["sigma"])

        return detector

# Rotate an image
#
# image: image to rotate
# x:     x-coordinate of point we wish to rotate around
# y:     y-coordinate of point we wish to rotate around
# angle: degrees to rotate image by
#
# Returns a rotated copy of the original image
def rotate(image, x, y, angle):
    img_r = cv2.getRotationMatrix2D((x, y), angle, 1.0)
    result = cv2.warpAffine(image, img_r, image.shape[1::-1], flags=cv2.INTER_LINEAR)
    cv2.imwrite('222.jpg', result)
    return result


# Get coordinates of center point.
#
# image:  Image that will be rotated
# return: (x, y) coordinates of point at center of image
def get_img_center(image):
    centre = tuple(np.array(image.shape[1::-1])/2)
    return centre


if __name__ == '__main__':
    # Read image with OpenCV and convert to grayscale
    img = cv2.imread('road_sign.jpg', 1)
    
    for angle in [0, -45, -90]:
        
        img_r = rotate(img, get_img_center(img)[0], get_img_center(img)[1], angle)
        gray= cv2.cvtColor(img,cv2.COLOR_BGR2GRAY)
        


        # Initialize SIFT detector
        
        a = SiftDetector()
        sift = a.get_detector(None)
        '''
        kp = sift.detect(gray, None)
        img_d = cv2.drawKeypoints(gray, kp, img)
        cv2.imwrite('33333.jpg', img_d)
        '''

        kp1, des1 = sift.detectAndCompute(img,None)
        kp2, des2 = sift.detectAndCompute(img_r,None)
        # BFMatcher with default params
        bf = cv2.BFMatcher()
        matches = bf.knnMatch(des1,des2,k=2)
        # Apply ratio test
        good = []
        for m,n in matches:
            if m.distance < 0.75*n.distance:
                good.append([m])
        # cv.drawMatchesKnn expects list of lists as matches.
        img3 = cv2.drawMatchesKnn(img,kp1,img_r,kp2,good,None,flags=cv2.DrawMatchesFlags_NOT_DRAW_SINGLE_POINTS)
        cv2.imwrite(str(-1 * angle) + '.jpg', img3)

    # Store SIFT keypoints of original image in a Numpy array
    


    # Rotate around point at center of image.
    


    # Degrees with which to rotate image
    


    # Number of times we wish to rotate the image
    

    
    # BFMatcher with default params
    

        # Rotate image
        

        # Compute SIFT features for rotated image
        

        
        # Apply ratio test
        


        # cv2.drawMatchesKnn expects list of lists as matches.
        
