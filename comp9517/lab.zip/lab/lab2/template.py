# Template for lab02 task 3

import cv2
import math
import numpy as np
import sys

class SiftDetector():
    def __init__(self, norm="L2", params=None):
        self.detector=self.get_detector(params)
        self.norm=norm

    def get_detector(self, params):
        if params is None:
            params={}
            params["n_features"]=0
            params["n_octave_layers"]=3
            params["contrast_threshold"]=0.04
            params["edge_threshold"]=10
            params["sigma"]=1.6

        detector = cv2.xfeatures2d.SIFT_create(
                nfeatures=params["n_features"],
                nOctaveLayers=params["n_octave_layers"],
                contrastThreshold=params["contrast_threshold"],
                edgeThreshold=params["edge_threshold"],
                sigma=params["sigma"])

        return detector

img = cv2.imread("road_sign.jpg",1)

#sift = cv2.xfeatures2d.SIFT_create(contrastThreshold = 0.25)
#kp = sift.detect(gray,None)
#img=cv2.drawKeypoints(gray,kp,img)
#cv2.imwrite('sift_keypoints.jpg',img)

# Rotate an image
#
# image: image to rotate
# x:     x-coordinate of point we wish to rotate around
# y:     y-coordinate of point we wish to rotate around
# angle: degrees to rotate image by
#
# Returns a rotated copy of the original image
def rotate(image, x, y, angle):
    
    center = (y/2,x/2)
    M = cv2.getRotationMatrix2D(center,angle,1.0)
    rotated = cv2.warpAffine(image,M,(y,x))
    return rotated

# Get coordinates of center point.
#
# image:  Image that will be rotated
# return: (x, y) coordinates of point at center of image
def get_img_center(image):
    a, b = image.shape[:2]
    x,y = a/2,b/2
    return (x,y)

x,y = img.shape[:2]
f = rotate(img,x,y,-45)

cv2.imwrite("a.jpg",f)

#if __name__ == '__main__':
    # Read image with OpenCV and convert to grayscale
    


    # Initialize SIFT detector
    


    # Store SIFT keypoints of original image in a Numpy array
    


    # Rotate around point at center of image.
    


    # Degrees with which to rotate image
    


    # Number of times we wish to rotate the image
    

    
    # BFMatcher with default params
    

        # Rotate image
        

        # Compute SIFT features for rotated image
        

        
        # Apply ratio test
        


        # cv2.drawMatchesKnn expects list of lists as matches.
        
