import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as mpimg

from scipy import ndimage as ndi
from skimage.morphology import watershed
from skimage.feature import peak_local_max
from sklearn.cluster import MeanShift

from PIL import Image

img_path = "pics/strawberry.png"
img = Image.open(img_path)
img_mat = np.array(img)[:, :, :3]

R = img_mat[:, :, 0]
G = img_mat[:, :, 1]
B = img_mat[:, :, 2]

colour_samples = np.column_stack((R.flatten(),G.flatten(),B.flatten()))

print(R.shape)
print(G.shape)
print(B.shape)

print(colour_samples.shape)
